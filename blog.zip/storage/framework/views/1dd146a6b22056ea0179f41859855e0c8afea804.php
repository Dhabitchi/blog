<?php $__env->startSection('content'); ?>


<div class="container mt-5">
    <h3>Edit Data</h3>
<form action="<?php echo e(route('update',['tpq'=>$tpq->k_id])); ?>" method="post">
    <?php echo method_field('patch'); ?>
	<?php echo csrf_field(); ?>
  Kode Kota:<br>
  <input type="text" name="k_kode" value="<?php echo e($tpq->k_kode); ?>">
  <br>
  Nama Kota:<br>
  <input type="text" name="k_nama" value="<?php echo e($tpq->k_nama); ?>">
  <br><br>
    <input type="submit" value="Submit" class="btn btn-dark btn-sm">
    <a href="<?php echo e(route('TPQ')); ?>" class="btn btn-dark btn-sm">Back</a>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/tpq/edit.blade.php ENDPATH**/ ?>